
import { randomUUID } from "node:crypto";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import pinoHttp from "pino-http";
import rateLimit from "express-rate-limit";

import { appConfig } from "./config/app.config.js";
import { isDatabaseConnected } from "./config/database.js";
import { APP_NAME, REQUEST_ID_HEADER } from "./constants/app.constants.js";
import {
  API_PREFIX,
  HEALTH_PATH,
  READINESS_PATH,
} from "./constants/api.constants.js";
import { AppError } from "./common/errors/app-error.js";
import { errorHandler } from "./common/errors/error-handler.js";
import { logger } from "./common/logging/logger.js";
import { notFoundMiddleware } from "./common/middleware/not-found.middleware.js";
import { authRouter } from "./modules/auth/auth.routes.js";
import { employeeRouter } from "./modules/employees/employee.routes.js";
import { scheduleRouter } from "./modules/schedules/schedule.routes.js";
import { attendanceRouter } from "./modules/attendance/attendance.routes.js";
import { whatsappWebhookRouter } from "./modules/integrations/whatsapp/whatsapp.webhook.js";
import { whatsappEnrollmentRouter } from "./modules/whatsapp-enrollment/whatsapp-enrollment.routes.js";
import { unknownContactRouter } from "./modules/unknown-contacts/unknown-contact.routes.js";

export const app = express();

app.disable("x-powered-by");

app.use(
  pinoHttp({
    logger,
    genReqId: (req, res) => {
      const incomingId = req.headers[REQUEST_ID_HEADER];

      const requestId =
        typeof incomingId === "string" && incomingId.length <= 128
          ? incomingId
          : randomUUID();

      res.setHeader(REQUEST_ID_HEADER, requestId);

      return requestId;
    },
  }),
);

app.use(helmet());

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || appConfig.corsOrigins.includes(origin)) {
        callback(null, true);
        return;
      }

      callback(
        new AppError(
          "Origin is not allowed by CORS.",
          403,
          "CORS_ORIGIN_NOT_ALLOWED",
        ),
      );
    },
  }),
);

// WhatsApp webhook must receive the raw request body for signature verification.
app.use("/webhooks/whatsapp", whatsappWebhookRouter);

app.use(express.json({ limit: "1mb" }));

const apiRateLimiter = rateLimit({
  windowMs: appConfig.apiRateLimit.windowMs,
  limit: appConfig.apiRateLimit.maxRequests,
  standardHeaders: true,
  legacyHeaders: false,
});

app.use(API_PREFIX, apiRateLimiter);

app.use(`${API_PREFIX}/auth`, authRouter);
app.use(`${API_PREFIX}/employees`, employeeRouter);
app.use(`${API_PREFIX}/schedules`, scheduleRouter);
app.use(`${API_PREFIX}/attendance`, attendanceRouter);
app.use(
  `${API_PREFIX}/whatsapp-enrollments`,
  whatsappEnrollmentRouter,
);
app.use(
  `${API_PREFIX}/unknown-contacts`,
  unknownContactRouter,
);

app.get(HEALTH_PATH, (_req, res) => {
  res.status(200).json({
    status: "ok",
    service: APP_NAME,
  });
});

app.get(READINESS_PATH, (_req, res) => {
  const databaseConnected = isDatabaseConnected();

  res.status(databaseConnected ? 200 : 503).json({
    status: databaseConnected ? "ready" : "not_ready",
    service: APP_NAME,
    dependencies: {
      database: databaseConnected ? "connected" : "disconnected",
    },
  });
});

app.use(notFoundMiddleware);
app.use(errorHandler);
